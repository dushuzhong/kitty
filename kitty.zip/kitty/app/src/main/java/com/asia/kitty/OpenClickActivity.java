package com.asia.kitty;

import android.support.v7.app.AppCompatActivity;
// 推送事件点击打开的页面
public class OpenClickActivity extends AppCompatActivity {


}
