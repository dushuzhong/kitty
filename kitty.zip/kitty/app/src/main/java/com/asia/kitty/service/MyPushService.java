package com.asia.kitty.service;

import cn.jpush.android.service.JCommonService;

public class MyPushService extends JCommonService {


}
