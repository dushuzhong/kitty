package com.asia.kitty.Adapter;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * viewHolder类似一个列表项的对象缓存
 * 目前在动物列表上使用的组件缓存对象
 */

public class ViewHolder {
    ImageView img_icon;
    TextView txt_aName;
    TextView txt_aSpeak;
}
