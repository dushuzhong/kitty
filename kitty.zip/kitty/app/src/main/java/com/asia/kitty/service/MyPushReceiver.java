package com.asia.kitty.service;

import cn.jpush.android.service.JPushMessageReceiver;

// 用户自定义接收消息器
public class MyPushReceiver extends JPushMessageReceiver {


}
